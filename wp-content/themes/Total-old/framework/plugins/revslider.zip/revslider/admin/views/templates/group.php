<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      http://www.themepunch.com/
 * @copyright 2016 ThemePunch
 */

if( !defined( 'ABSPATH') ) exit();

?>

<div id="rs-layout-composer">
	
	<input type="text" name="rs-row-layout"> <a class="button-primary revblue" id="rs-check-row-layout" href="javascript:void(0);"><?php _e('Update', 'revslider'); ?></a> <?php _e('Layout like 1/2 + 1/4 + 1/4', 'revslider'); ?>
</div>
<script type="text/javascript">
	
</script>